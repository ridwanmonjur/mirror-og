<br><br>
<div class="time-line-box time-line-box-success" id="timeline-box">
    <div class="swiper-container text-center">
        <div class="swiper-wrapper">
            <div class="swiper-slide swiper-slide__left" id="timeline-1">
                <div class="timestamp"><span class="cat">Categories</span></div>
                <div class="status__left status__left__success"><span><small>✔</small></span></div>
            </div>
            <div class="swiper-slide" id="timeline-2">
                <div class="timestamp"><span>Details</span></div>
                <div class="status status__left__success"><span><small>✔</small></span></div>
            </div>
             <div class="swiper-slide swiper-slide" id="timeline-launch">
                <div class="timestamp"><span class="date">Launch</span></div>
                <div class="status status__left__success"><span><small>✔</small></span></div>
            </div>
            <div class="swiper-slide__right" id="timeline-payment">
                <div class="timestamp"><span>Payment</span></div>
                <div class="status__right"><span><small>✔</small></span></div>
            </div>
           
        </div>
    </div>
</div>
