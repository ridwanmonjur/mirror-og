@include('Auth.Layout.HeadTag')
<body>
<div class="wrapper">
    <h2>Test Email</h2>
    <p>{{ $test_message }}</p>
    </div> 
</body>


 
