<body>

    <div class="wrapper">

        @yield('signUpbody')

    </div>

</body>
