<body>
    <div class="wrapper">


        @yield('signInbody')



    </div>


    <script src="{{ asset('/assets/js/auth/validity.js') }}"></script>


</body>
