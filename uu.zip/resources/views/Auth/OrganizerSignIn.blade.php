{{-- Page Title Goes Here  --}}

@section('title') {{'Organizer Sign In'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.OrganizerSignInLayout')
