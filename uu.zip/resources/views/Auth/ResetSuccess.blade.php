{{-- Page Title Goes Here  --}}

@section('title') {{'Request Verified'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.ResetSuccessLayout')
