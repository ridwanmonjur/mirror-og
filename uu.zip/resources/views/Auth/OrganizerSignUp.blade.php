{{-- Page Title Goes Here  --}}

@section('title') {{'Organizer Sign Up'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.OrganizerSignUpLayout')
