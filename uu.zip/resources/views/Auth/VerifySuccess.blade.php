{{-- Page Title Goes Here  --}}

@section('title') {{'Success Verified'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.VerifySuccessLayout')
