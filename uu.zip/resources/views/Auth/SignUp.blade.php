{{-- Page Title Goes Here  --}}

@section('title') {{'Sign Up'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.SignUpLayout')
