{{-- Page Title Goes Here  --}}

@section('title') {{'Sign In'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.SignInLayout')
