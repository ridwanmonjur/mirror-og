{{-- Page Title Goes Here  --}}

@section('title') {{'Reset Password'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.ResetPasswordLayout')
