{{-- Page Title Goes Here  --}}

@section('title') {{'Forgot Password'}} @endsection

{{-- extended the Sign page --}}

@extends('Auth.Layout.ForgetPasswordLayout')
